#include <stdio.h>

int main() {

     int nota[5];
     int i;

   // solicitar as 5 notas ao usuário
   for (int i = 0; i < 5; i++) {
      printf("Digite a nota %d: ", i + 1);
      scanf("%d", &nota[i]);
    }

   // exibir as 5 notas armazenadas no vetor
   for (int i = 0; i < 5; i++) {
      printf("%d\n", nota[i]);
    }
    
    return 0;
}