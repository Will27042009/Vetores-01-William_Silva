#include <stdio.h>

int main() {

 int nota[5] = {10,8,10,9,7};
 int i;

for (int i = 0; i < 5; i++) {
  printf("%d\n", nota[i]);
 }
    
    return 0;
}